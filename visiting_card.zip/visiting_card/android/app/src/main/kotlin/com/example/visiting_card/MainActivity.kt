package com.example.visiting_card

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
